from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from fastapi import Depends
from uuid import UUID
from app.core.database import get_db
from app.modules.dashboard.service import DashboardService
from app.modules.menu.model import Menu
from app.modules.menu_items.model import MenuItem
from app.modules.promotions.model import Promotion


router = APIRouter()

templates = Jinja2Templates(directory="app/templates")


# ======================================================
# LOGIN
# ======================================================

@router.get("/")
async def public_home(
    request: Request,
    db: Session = Depends(get_db)
):
    """Landing pública del restaurante. No requiere autenticación."""

    active_menu = (
        db.query(Menu)
        .filter(Menu.active == True)
        .order_by(Menu.display_order.asc(), Menu.created_at.desc())
        .first()
    )

    menu_items = []
    if active_menu:
        menu_items = (
            db.query(MenuItem)
            .join(MenuItem.dish)
            .filter(
                MenuItem.menu_id == active_menu.id,
                MenuItem.active == True,
            )
            .order_by(MenuItem.display_order.asc(), MenuItem.id.asc())
            .all()
        )

    promotions = (db.query(Promotion).filter(Promotion.active == True)
                  .order_by(Promotion.display_order.asc(), Promotion.created_at.desc()).all())
    return templates.TemplateResponse(
        request=request,
        name="public/home.html",
        context={"active_menu": active_menu, "menu_items": menu_items, "promotions": promotions}
    )


@router.get("/login")
async def customer_login(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="auth/login.html",
        context={"login_mode": "customer"}
    )


@router.get("/admin/login")
async def admin_login(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="auth/admin_login.html",
        context={"login_mode": "admin"}
    )


@router.get("/checkout")
async def customer_checkout(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="public/checkout.html",
        context={}
    )


@router.get("/mis-pedidos")
async def customer_orders_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="public/customer_orders.html",
        context={}
    )


@router.get("/domiciliario")
async def courier_page(request: Request):
    return templates.TemplateResponse(request=request, name="delivery/dashboard.html", context={})

@router.get("/push-sw.js")
async def push_service_worker():
    return FileResponse("app/static/push-sw.js", media_type="application/javascript")

@router.get("/terms")
async def terms(request: Request):
    return templates.TemplateResponse(request=request, name="public/terms.html", context={})


@router.get("/privacy")
async def privacy(request: Request):
    return templates.TemplateResponse(request=request, name="public/privacy.html", context={})


@router.get("/register")
async def customer_register(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="auth/register.html",
        context={}
    )



@router.get("/admin/support")
async def admin_support(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="admin/support.html",
        context={}
    )

# ======================================================
# DASHBOARD
# ======================================================

@router.get("/admin")
async def dashboard(
    request: Request,
    db: Session = Depends(get_db)
):

    dashboard = DashboardService(db)

    datos = dashboard.get_dashboard()

    return templates.TemplateResponse(
        request=request,
        name="admin/dashboard.html",
        context=datos
    )


# ======================================================
# USUARIOS Y ASISTENCIA
# ======================================================

@router.get("/admin/orders")
async def admin_orders_page(request: Request):
    """Vista administrativa para seguimiento de pedidos y domiciliarios."""
    return templates.TemplateResponse(
        request=request,
        name="admin/orders.html",
        context={}
    )


@router.get("/admin/users")
async def admin_users(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="admin/settings/users.html",
        context={}
    )


@router.get("/admin/attendance")
async def admin_attendance(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="admin/attendance.html",
        context={}
    )


@router.get("/asistencia")
async def attendance_kiosk(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="attendance/kiosk.html",
        context={}
    )


# ======================================================
# MESAS
# ======================================================

@router.get("/admin/tables")
async def tables(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/tables/index.html",
        context={}
    )


@router.get("/admin/tables/create")
async def tables_create(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/tables/create.html",
        context={}
    )


@router.get("/admin/tables/edit/{table_id}")
async def tables_edit(request: Request, table_id: int):

    return templates.TemplateResponse(
        request=request,
        name="admin/tables/edit.html",
        context={"table_id": table_id}
    )


# ======================================================
# CONFIGURACIÓN
# ======================================================

@router.get("/admin/settings")
async def settings(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/settings/index.html",
        context={}
    )


# ======================================================
# CATEGORÍAS
# ======================================================

@router.get("/admin/menu/categories")
async def categories(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/categories/index.html",
        context={}
    )
# ======================================================
# CREAR CATEGORÍA
# ======================================================

@router.get("/admin/menu/categories/create")
async def categories_create(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/categories/create.html",
        context={}
    )

# ======================================================
# EDITAR CATEGORÍA
# ======================================================

@router.get("/admin/menu/categories/edit/{category_id}")
async def categories_edit(
    request: Request,
    category_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/categories/edit.html",
        context={
            "category_id": category_id
        }
    )

# ======================================================
# PRODUCTOS
# ======================================================

@router.get("/admin/menu/products")
async def products(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/products/index.html",
        context={}
    )


@router.get("/admin/menu/products/create")
async def products_create(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/products/create.html",
        context={}
    )


@router.get("/admin/menu/products/edit/{product_id}")
async def products_edit(
    request: Request,
    product_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/products/edit.html",
        context={
            "product_id": product_id
        }
    )


# ======================================================
# COCINA / ESTACIONES
# ======================================================

@router.get("/admin/inventory")
async def admin_inventory(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/inventory.html",
        context={}
    )


@router.get("/admin/kitchen")
async def kitchen_dashboard(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/kitchen/index.html",
        context={}
    )


# ======================================================
# MENÚ DIGITAL
# ======================================================

@router.get("/admin/menu")
async def menu_page(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/index.html",
        context={}
    )


@router.get("/admin/menu/create")
async def menu_create(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/create.html",
        context={}
    )


@router.get("/admin/menu/edit/{menu_id}")
async def menu_edit(
    request: Request,
    menu_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/edit.html",
        context={
            "menu_id": menu_id
        }
    )

# ======================================================
# QR DEL MENÚ
# ======================================================

@router.get("/admin/menu/{menu_id}/qrs")
async def menu_qrs(
    request: Request,
    menu_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/menu/qrs.html",
        context={
            "menu_id": menu_id
        }
    )

# ======================================================
# PLATOS
# ======================================================

@router.get("/admin/dishes")
async def dishes(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/dishes/index.html",
        context={}
    )


@router.get("/admin/dishes/create")
async def dishes_create(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/dishes/create.html",
        context={}
    )


@router.get("/admin/dishes/edit/{dish_id}")
async def dishes_edit(
    request: Request,
    dish_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/dishes/edit.html",
        context={
            "dish_id": dish_id
        }
    )


@router.get("/admin/dishes/view/{dish_id}")
async def dishes_view(
    request: Request,
    dish_id: UUID
):

    return templates.TemplateResponse(
        request=request,
        name="admin/dishes/view.html",
        context={
            "dish_id": dish_id
        }
    )

# ======================================================
# CONTROL ADMINISTRATIVO DE CAJAS
# ======================================================

@router.get("/admin/cash-control")
async def admin_cash_control(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="admin/cash_control.html",
        context={}
    )


# ======================================================
# MENÚ PÚBLICO DEL CLIENTE
# ======================================================
@router.get("/m/{table_number}")
async def customer_menu(request: Request, table_number: int, db: Session = Depends(get_db)):
    from app.modules.dishes.model import Dish
    from app.modules.categories.model import Category
    from app.modules.tables.model import Table
    table = db.query(Table).filter(Table.number == table_number, Table.active == True).first()
    if not table:
        from fastapi import HTTPException
        raise HTTPException(404, "Mesa no encontrada")
    categories = db.query(Category).filter(Category.active == True).order_by(Category.display_order.asc(), Category.name.asc()).all()
    dishes = db.query(Dish).filter(Dish.active == True, Dish.available == True).order_by(Dish.name.asc()).all()
    return templates.TemplateResponse(request=request, name="public/menu.html", context={"table_number": table_number, "table_id": table.id, "categories": categories, "dishes": dishes})

@router.get("/waiter")
async def waiter_view(request: Request):
    return templates.TemplateResponse(request=request, name="waiter/index.html", context={})

@router.get("/kitchen")
async def kitchen_selector(request: Request):
    return templates.TemplateResponse(request=request, name="kitchen/index.html", context={})


@router.get("/kitchen/{screen_code}")
async def kitchen_view(request: Request, screen_code: str):
    return templates.TemplateResponse(request=request, name="kitchen/index.html", context={})


@router.get("/kitchen/station/{station_id}")
async def kitchen_station_view(request: Request, station_id: str):
    # La estación es la identidad de esta pantalla.
    # No se redirige a una estación principal por prioridad o categoría.
    return templates.TemplateResponse(request=request, name="kitchen/index.html", context={})

# ======================================================
# CAJA
# ======================================================

@router.get("/admin/cashier")
async def cashier_page(request: Request):

    from fastapi.responses import RedirectResponse

    return RedirectResponse(url="/admin/cash-control", status_code=307)


# ======================================================
# CAJA - ACCESO DIRECTO
# ======================================================

@router.get("/cashier")
async def cashier_page_direct(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="cashier/index.html",
        context={}
    )