
const STORAGE_KEY = "kitchen_selected_station_id";

let items = [];
let historyItems = [];
let selectedStation = null;
let currentScreenCode = null;
let currentStationId = null;

// ==========================================================
// SONIDO DE ALERTA
// ==========================================================

let alertAudioContext = null;
let kitchenKnownQueueIds = new Set();
let kitchenQueueSnapshotReady = false;

function ensureAlertAudio() {
    try {
        if (!alertAudioContext) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return null;
            alertAudioContext = new AudioCtx();
        }
        if (alertAudioContext.state === "suspended") {
            alertAudioContext.resume().catch(() => {});
        }
        return alertAudioContext;
    } catch (error) {
        console.warn("No fue posible inicializar el sonido de cocina:", error);
        return null;
    }
}

function playKitchenAlert() {
    const ctx = ensureAlertAudio();
    if (!ctx) return;

    const now = ctx.currentTime;
    [0, 0.16].forEach((offset, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = index === 0 ? 880 : 1175;
        gain.gain.setValueAtTime(0.0001, now + offset);
        gain.gain.exponentialRampToValueAtTime(0.18, now + offset + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.13);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + offset);
        osc.stop(now + offset + 0.14);
    });
}

document.addEventListener("pointerdown", ensureAlertAudio, { once: true });


// ==========================================================
// FECHAS
// ==========================================================

function parseBackendDate(value) {

    if (!value) return null;

    let text = String(value);

    // FastAPI está devolviendo fechas sin zona horaria.
    // Nuestro backend las guarda como UTC.
    if (
        !text.endsWith("Z") &&
        !text.includes("+")
    ) {
        text += "Z";
    }

    return new Date(text);
}


function elapsedFrom(start, end = Date.now()) {

    const date = parseBackendDate(start);

    if (!date || Number.isNaN(date.getTime())) {
        return 0;
    }

    return Math.max(
        0,
        Math.floor(
            (end - date.getTime()) / 1000
        )
    );
}


function elapsedBetween(start, end) {

    const a = parseBackendDate(start);
    const b = parseBackendDate(end);

    if (
        !a ||
        !b ||
        Number.isNaN(a.getTime()) ||
        Number.isNaN(b.getTime())
    ) {
        return 0;
    }

    return Math.max(
        0,
        Math.floor(
            (b.getTime() - a.getTime()) / 1000
        )
    );
}


function fmt(seconds) {

    seconds = Math.max(
        0,
        Number(seconds) || 0
    );

    const hours = Math.floor(seconds / 3600);

    const minutes = Math.floor(
        (seconds % 3600) / 60
    );

    const secs = seconds % 60;

    if (hours > 0) {

        return (
            String(hours).padStart(2, "0") +
            ":" +
            String(minutes).padStart(2, "0") +
            ":" +
            String(secs).padStart(2, "0")
        );
    }

    return (
        String(minutes).padStart(2, "0") +
        ":" +
        String(secs).padStart(2, "0")
    );
}


function formatClock(value) {

    const date = parseBackendDate(value);

    if (!date) return "—";

    return date.toLocaleTimeString(
        "es-CO",
        {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }
    );
}


// ==========================================================
// UTILIDADES
// ==========================================================

function escapeHtml(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


// ==========================================================
// ESTACIONES
// ==========================================================

async function getStations() {

    const response =
        await fetch("/api/stations/");

    if (!response.ok) {
        throw new Error(
            "No se pudieron cargar las estaciones."
        );
    }

    return response.json();
}


async function getScreens() {

    const response =
        await fetch("/api/screens/");

    if (!response.ok) {
        return [];
    }

    return response.json();
}


function renderStations(stations, screens) {

    const root =
        document.getElementById("stations");

    const savedId =
        localStorage.getItem(STORAGE_KEY);

    const activeStations =
        stations.filter(
            station => station.active !== false
        );

    if (!activeStations.length) {

        root.innerHTML = `
            <div class="empty-panel">
                <strong>No hay estaciones registradas.</strong>
                <span>
                    Primero crea una estación desde
                    Administración → Cocina.
                </span>
            </div>
        `;

        return;
    }

    const screenByStation =
        new Map();

    screens
        .filter(screen => screen.active !== false)
        .forEach(screen => {

            if (
                !screenByStation.has(
                    String(screen.station_id)
                )
            ) {

                screenByStation.set(
                    String(screen.station_id),
                    screen
                );
            }
        });


    root.innerHTML =
        activeStations.map(
            (station, index) => {

                const id =
                    String(station.id);

                const screen =
                    screenByStation.get(id);

                const isSaved =
                    savedId === id;

                const isPrimary =
                    station.priority === 1 ||
                    index === 0;

                const color =
                    station.color ||
                    "#00d2ff";

                return `
                    <button
                        class="station-card ${isSaved ? "selected" : ""}"
                        data-station-id="${escapeHtml(id)}"
                        style="--station-color:${escapeHtml(color)}"
                    >

                        <div class="station-card-top">

                            <span class="station-icon">
                                ${isPrimary ? "★" : "▦"}
                            </span>

                            <div class="station-tags">

                                ${
                                    isPrimary
                                        ? '<span class="tag primary">PRINCIPAL</span>'
                                        : ""
                                }

                                ${
                                    isSaved
                                        ? '<span class="tag saved">SELECCIONADA</span>'
                                        : ""
                                }

                            </div>

                        </div>

                        <h3>
                            ${escapeHtml(station.name)}
                        </h3>

                        <p>
                            ${escapeHtml(
                                station.description ||
                                "Estación de preparación"
                            )}
                        </p>

                        <div class="station-card-bottom">

                            <span>
                                ${
                                    screen
                                        ? "Pantalla registrada"
                                        : "Pantalla se creará automáticamente"
                                }
                            </span>

                            <span class="arrow">
                                →
                            </span>

                        </div>

                    </button>
                `;
            }
        ).join("");


    root
        .querySelectorAll(".station-card")
        .forEach(card => {

            card.addEventListener(
                "click",
                () =>
                    selectStation(
                        card.dataset.stationId,
                        activeStations
                    )
            );
        });


    document
        .getElementById("selectedBadge")
        .classList
        .toggle(
            "hidden",
            !savedId
        );
}


// ==========================================================
// SELECCIONAR ESTACIÓN
// ==========================================================

async function selectStation(
    stationId,
    stations
) {

    const station =
        stations.find(
            item =>
                String(item.id) ===
                String(stationId)
        );

    if (!station) return;

    const buttons =
        document.querySelectorAll(
            ".station-card"
        );

    buttons.forEach(
        button =>
            button.disabled = true
    );

    try {

        const response =
            await fetch(
                `/api/screens/ensure/${encodeURIComponent(station.id)}`,
                {
                    method: "POST"
                }
            );

        if (!response.ok) {

            throw new Error(
                "No se pudo preparar la pantalla de esta estación."
            );
        }

        const screen =
            await response.json();

        localStorage.setItem(
            STORAGE_KEY,
            String(station.id)
        );

        localStorage.setItem(
            "kitchen_selected_station_name",
            station.name
        );

        localStorage.setItem(
            "kitchen_selected_screen_code",
            screen.code
        );

        // Cada pantalla queda vinculada a la estación elegida.
        // No usamos prioridad ni "Principal" para redireccionar.
        window.location.href =
            `/kitchen/station/${encodeURIComponent(station.id)}`;

    } catch (error) {

        alert(
            error.message ||
            "No se pudo seleccionar la estación."
        );

        buttons.forEach(
            button =>
                button.disabled = false
        );
    }
}


// ==========================================================
// SELECTOR
// ==========================================================

function showSelector() {

    document
        .getElementById("stationSelector")
        .classList
        .remove("hidden");

    document
        .getElementById("kitchenBoard")
        .classList
        .add("hidden");

    document
        .getElementById("changeStationBtn")
        .classList
        .add("hidden");

    document
        .getElementById("screenTitle")
        .textContent =
        "Seleccionar estación";

    document
        .getElementById("screenSubtitle")
        .textContent =
        "Selecciona manualmente la estación que atenderá esta pantalla.";

    loadStationSelector();
}


async function loadStationSelector() {

    const root =
        document.getElementById("stations");

    try {

        const [
            stations,
            screens
        ] = await Promise.all([
            getStations(),
            getScreens()
        ]);

        renderStations(
            stations,
            screens
        );

    } catch (error) {

        root.innerHTML = `
            <div class="empty-panel">

                <strong>
                    No se pudieron cargar las estaciones.
                </strong>

                <span>
                    Revisa que el servidor esté funcionando.
                </span>

            </div>
        `;
    }
}


// ==========================================================
// HEARTBEAT
// ==========================================================

async function heartbeat() {

    if (!currentScreenCode) return;

    fetch(
        `/api/screens/${encodeURIComponent(currentScreenCode)}/heartbeat`,
        {
            method: "POST"
        }
    ).catch(() => {});
}


// ==========================================================
// CARGAR COLA
// ==========================================================

async function loadBoard() {

    // En una ruta por estación no necesitamos screenCode todavía.
    // La estación seleccionada es la autoridad de la cola.
    if (!currentStationId && !currentScreenCode) return;

    const queueUrl = currentStationId
        ? `/api/screens/by-station/${encodeURIComponent(currentStationId)}/queue`
        : `/api/screens/${encodeURIComponent(currentScreenCode)}/queue`;

    const response =
        await fetch(queueUrl);

    if (!response.ok) {

        showSelector();

        return;
    }

    const data =
        await response.json();

    selectedStation = data;
    if (data.screen_code) currentScreenCode = data.screen_code;

    document
        .getElementById("stationSelector")
        .classList
        .add("hidden");

    document
        .getElementById("kitchenBoard")
        .classList
        .remove("hidden");

    document
        .getElementById("changeStationBtn")
        .classList
        .remove("hidden");

    document
        .getElementById("screenTitle")
        .textContent =
        data.screen || "Cocina";

    document
        .getElementById("screenSubtitle")
        .textContent =
        "Pantalla asignada a esta estación · cola automática";

    document
        .getElementById("stationName")
        .textContent =
        data.screen || "Cocina";

    document
        .getElementById("stationDescription")
        .textContent =
        "Cola automática · orden de llegada";

    const nextItems = data.items || [];

    // No sonar al abrir la pantalla: solo avisamos cuando llega algo nuevo
    // después de que la estación ya quedó cargada.
    if (!kitchenQueueSnapshotReady) {
        kitchenKnownQueueIds = new Set(
            nextItems
                .filter(item => item.status === "WAITING")
                .map(item => String(item.id))
        );
        kitchenQueueSnapshotReady = true;
    } else {
        const newWaiting = nextItems.filter(item =>
            item.status === "WAITING" &&
            !kitchenKnownQueueIds.has(String(item.id))
        );
        if (newWaiting.length) {
            playKitchenAlert();
        }
        kitchenKnownQueueIds = new Set(
            nextItems
                .filter(item => item.status === "WAITING")
                .map(item => String(item.id))
        );
    }

    items = nextItems;

    const queueCount =
        document.getElementById(
            "queueCount"
        );

    if (queueCount) {

        queueCount.textContent =
            items.length;
    }

    render();

    await loadHistory();
}


// ==========================================================
// RENDER COLA
// ==========================================================

function render() {
    const root = document.getElementById("queue");
    if (!items.length) {
        root.innerHTML = `<div class="empty-panel queue-empty"><div class="empty-icon">✓</div><strong>No hay comandas pendientes</strong><span>Los nuevos pedidos aparecerán automáticamente.</span></div>`;
        return;
    }
    root.innerHTML = items.map(item => {
        const waiting = item.status === "WAITING";
        const preparing = item.status === "PREPARING";
        const ready = item.status === "READY";
        const prepLimit = Math.max(0, Number(item.preparation_time || 0));
        const prepSeconds = preparing && item.started_at ? elapsedFrom(item.started_at) : 0;
        const overdue = preparing && prepLimit > 0 && prepSeconds > prepLimit * 60;
        const overdueSeconds = overdue ? prepSeconds - prepLimit * 60 : 0;
        const waitingTime = waiting ? elapsedFrom(item.created_at) : (item.waiting_seconds || (item.started_at ? elapsedBetween(item.created_at, item.started_at) : 0));
        const preparationTime = preparing ? prepSeconds : (ready && item.started_at && item.finished_at ? elapsedBetween(item.started_at, item.finished_at) : 0);
        const totalTime = waiting ? waitingTime : (item.finished_at ? elapsedBetween(item.created_at, item.finished_at) : waitingTime + preparationTime);
        const stateClass = overdue ? "overdue" : (ready ? "ready" : String(item.status).toLowerCase());
        return `<article class="ticket ${stateClass}" data-item-id="${escapeHtml(item.id)}">
            <div class="ticket-head"><small>COMANDA ${item.order_id ? escapeHtml(item.order_id.slice(0, 8).toUpperCase()) : "—"} · MESA ${escapeHtml(item.table || "—")}</small><small>${waiting ? "NUEVA" : ready ? "LISTO · ESPERA MESERO" : overdue ? "⚠ ATRASADO" : "PREPARANDO"}</small></div>
            <h2>${escapeHtml(item.quantity)} × ${escapeHtml(item.name)}</h2>
            ${waiting ? `<div class="time-main-label">ESPERA EN COCINA</div><div class="timer" data-mode="waiting" data-created="${escapeHtml(item.created_at)}">${fmt(waitingTime)}</div>${prepLimit ? `<div class="target-time">⏱ Tiempo objetivo: <b>${prepLimit} min</b></div>` : ""}` : ready ? `<div class="ready-banner">✓ LISTO — esperando que el mesero marque <b>ENTREGADO</b></div><div class="time-grid"><div><span>ESPERA</span><strong>${fmt(waitingTime)}</strong></div><div><span>PREPARACIÓN</span><strong>${fmt(preparationTime)}</strong></div><div><span>TOTAL</span><strong>${fmt(totalTime)}</strong></div></div>` : `<div class="time-grid"><div><span>ESPERA</span><strong>${fmt(waitingTime)}</strong></div><div><span>PREPARACIÓN</span><strong class="preparation-timer" data-started="${escapeHtml(item.started_at)}">${fmt(prepSeconds)}</strong></div><div><span>TOTAL</span><strong class="total-timer" data-created="${escapeHtml(item.created_at)}">${fmt(waitingTime + prepSeconds)}</strong></div></div><div class="prep-target ${overdue ? "late" : ""}">${overdue ? `⚠ ATRASADO <b>${fmt(overdueSeconds)}</b> · objetivo ${prepLimit} min` : `⏱ Objetivo ${prepLimit ? prepLimit + " min" : "sin límite"}`}</div>`}
            ${waiting ? `<button onclick="changeStatus('${escapeHtml(item.id)}','WAITING')">Tomar pedido</button>` : preparing ? `<button onclick="changeStatus('${escapeHtml(item.id)}','PREPARING')">Marcar listo</button>` : `<button class="station-locked" type="button" disabled>🔒 Esperando entrega del mesero</button>`}
        </article>`;
    }).join("");
}

function tickTimers() {
    document.querySelectorAll(".timer[data-mode='waiting']").forEach(element => element.textContent = fmt(elapsedFrom(element.dataset.created)));
    document.querySelectorAll(".preparation-timer").forEach(element => {
        const seconds = elapsedFrom(element.dataset.started); element.textContent = fmt(seconds);
        const ticket = element.closest('.ticket'); const item = items.find(x => String(x.id) === String(ticket?.dataset.itemId));
        if (!ticket || !item || item.status !== 'PREPARING') return;
        const limit = Number(item.preparation_time || 0) * 60; const overdue = limit > 0 && seconds > limit;
        ticket.classList.toggle('overdue', overdue);
        const target = ticket.querySelector('.prep-target');
        if (target) target.classList.toggle('late', overdue);
        if (target && overdue) target.innerHTML = `⚠ ATRASADO <b>${fmt(seconds - limit)}</b> · objetivo ${Number(item.preparation_time)} min`;
    });
    document.querySelectorAll(".total-timer").forEach(element => element.textContent = fmt(elapsedFrom(element.dataset.created)));
}

// ==========================================================
// CAMBIAR ESTACIÓN
// ==========================================================

document
    .getElementById("changeStationBtn")
    .addEventListener(
        "click",
        () => {

            currentScreenCode = null;

            showSelector();
        }
    );


// ==========================================================
// HISTORIAL BOTÓN
// ==========================================================

const toggleHistoryBtn =
    document.getElementById(
        "toggleHistoryBtn"
    );

if (toggleHistoryBtn) {

    toggleHistoryBtn.addEventListener(
        "click",
        () => {

            const history =
                document.getElementById(
                    "history"
                );

            if (!history) return;

            const hidden =
                history.classList.toggle(
                    "hidden"
                );

            toggleHistoryBtn.textContent =
                hidden
                    ? "Ver historial"
                    : "Ocultar historial";
        }
    );
}


// ==========================================================
// RELOJ
// ==========================================================

function updateClock() {

    const clock =
        document.getElementById("clock");

    if (!clock) return;

    clock.textContent =
        new Date().toLocaleTimeString(
            "es-CO",
            {
                hour: "2-digit",
                minute: "2-digit"
            }
        );
}


// ==========================================================
// INICIO
// ==========================================================

async function boot() {

    const pathParts =
        window.location.pathname
            .split("/")
            .filter(Boolean);

    const stationFromUrl =
        pathParts[0] === "kitchen" &&
        pathParts[1] === "station" &&
        pathParts[2]
            ? decodeURIComponent(pathParts[2])
            : null;

    const screenFromUrl =
        pathParts[0] === "kitchen" &&
        pathParts[1] &&
        pathParts[1] !== "station"
            ? decodeURIComponent(pathParts[1])
            : null;

    if (stationFromUrl) {
        currentStationId = stationFromUrl;
        await loadBoard();

        heartbeat();

        setInterval(
            loadBoard,
            5000
        );

        setInterval(
            heartbeat,
            15000
        );

        return;
    }

    // Compatibilidad con enlaces antiguos /kitchen/TV-...
    if (screenFromUrl) {
        currentScreenCode = screenFromUrl;
        await loadBoard();
        heartbeat();
        setInterval(loadBoard, 5000);
        setInterval(heartbeat, 15000);
        return;
    }

    showSelector();
}


// ==========================================================
// INTERVALOS
// ==========================================================

setInterval(
    tickTimers,
    1000
);

setInterval(
    updateClock,
    1000
);

updateClock();

boot();


document.getElementById("enableKitchenPush")?.addEventListener("click", async () => { try { await window.ImperioPush.enable({stationId:selectedStation?.station_id || localStorage.getItem(STORAGE_KEY)}); alert("🔔 Alertas activadas para esta estación."); } catch(e){ alert(e.message || "No se pudieron activar las alertas."); } });

document.getElementById("logoutKitchen")?.addEventListener("click",()=>{localStorage.removeItem("token");localStorage.removeItem("user");window.location.replace("/login");});
